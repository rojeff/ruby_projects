#!/usr/bin/env bash -e
source "$rvm_scripts_path/rvm" || true
rvm install ree-1.8.7-2011.03 
